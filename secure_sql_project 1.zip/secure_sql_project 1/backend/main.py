from fastapi import FastAPI, Depends, HTTPException, Form
from sqlalchemy.orm import Session
from database import SessionLocal, engine
from models import User, Base
from security import encrypt_data, decrypt_data
from auth import generate_capability_code

Base.metadata.create_all(bind=engine)

app = FastAPI()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@app.post("/register")
def register(email: str = Form(...), password: str = Form(...), db: Session = Depends(get_db)):
    encrypted_password = encrypt_data(password)
    cap_code = generate_capability_code()
    user = User(email=email, password=encrypted_password, capability_code=cap_code)
    db.add(user)
    db.commit()
    return {"message": "User registered", "capability_code": cap_code}

@app.post("/login")
def login(email: str = Form(...), password: str = Form(...), capability_code: str = Form(...), db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == email).first()
    if not user:
        raise HTTPException(status_code=401, detail="Invalid email")
    if decrypt_data(user.password) != password:
        raise HTTPException(status_code=401, detail="Invalid password")
    if user.capability_code != capability_code:
        raise HTTPException(status_code=403, detail="Capability code invalid")
    return {"message": "Login successful – SQL Injection prevented"}
