import secrets

def generate_capability_code():
    return secrets.token_hex(16)
